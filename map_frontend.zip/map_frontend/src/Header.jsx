function Header() {
  return (
    <header id="welcome">
      <h1>Welcome To Safety Miles</h1>
    </header>
  );
}

export default Header;
