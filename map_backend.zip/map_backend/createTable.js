const db= require('./database.js')


async function createProductTable() {
    console.log("creating product table")
    try {
        const res = await db.query(
            'CREATE TABLE police_data (\
                id SERIAL PRIMARY KEY,\
                latitude DOUBLE PRECISION,\
                longitude DOUBLE PRECISION,\
                incident VARCHAR(255),\
                date_of_incident DATE\
            );');
        console.log(res);
    } catch (err) {
        console.error(err);
    } finally {
        db.end();
    }

}


createProductTable()

// module.exports = res;