const  express = require('express')
const router = express.Router()

const db= require('./database.js')

router.get('/all',async (req, res) => {
    

    try {
        const result = await db.query(
            'SELECT * FROM police_data\
            order by id'
              );
            
        console.log(result.rows);
        res.send(result.rows);
    } catch (err) {
        console.error(err);
        res.send(err);

    }

    

    
})


router.post('/new', async (req, res) => {
    const newProduct = req.body
    
    try {

       
        
        const result = await db.query(
            "INSERT INTO police_data (latitude, longitude, incident, date_of_incident)\
            VALUES (23.7504569,90.4203698,'Assault', '2022-01-04'),\
            (23.7504569,90.4203698,'Theft', '2023-05-03'),\
            (23.7504569,90.4203698,'Snatching', '2024-05-03'),\
            (23.7504644,90.4210764,'Robbery', '2024-03-01'),\
            (23.7504644,90.4210764,'Theft', '2022-01-04'),\
            (23.7342718,90.3924343,'Robbery', '2024-05-03'),\
            (23.7342718,90.3924343,'Robbery', '2021-05-03'),\
            (23.7338886,90.3925475,'Theft', '2022-05-03'),\
            (23.7338646,90.3943726,'Assault', '2020-05-03'),\
            (23.7338646,90.3943726,'Robbery', '2024-05-03'),\
            (23.7338646,90.3943726,'Robbery', '2024-05-03'),\
            (23.7273183,90.4026561,'Robbery', '2021-05-03'),\
            (23.7273183,90.4026561,'Snatching', '2023-05-03'),\
            (23.7279987,90.3985509,'Robbery', '2022-05-03'),\
            (23.7279987,90.3985509,'Theft', '2021-05-03'),\
            (23.7279987,90.3985509,'Robbery', '2023-05-03'),\
            (23.7280853,90.3982223,'Robbery', '2022-05-03');");
            
        console.log(result);
        res.send(result);
    } catch (err) {
        console.error(err);
        res.send(err);

    } 

})

module.exports = router