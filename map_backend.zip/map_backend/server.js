const express = require('express')
const app = express()

const cors = require('cors');



// Use CORS middleware
app.use(cors());

const Police_data = require('./Police_data')

app.use('/api/incident', Police_data)


app.listen(5001, () => {
    console.log("server is running ")
})