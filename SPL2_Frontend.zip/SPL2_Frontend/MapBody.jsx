function MapBody(){
    <div id="container">
      <div id="map"></div>
    </div>
}

export default MapBody;